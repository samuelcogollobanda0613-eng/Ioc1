package com.ioc1.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Pantalla de búsqueda: escribe y encuentra tus apps al instante. */
class SearchOverlay(
    context: Context,
    private val onLaunch: (AppInfo, View?) -> Unit
) : FrameLayout(context) {

    private val content = LinearLayout(context)
    private val input = EditText(context)
    private val results = LinearLayout(context)
    private var current: List<AppInfo> = emptyList()

    var apps: List<AppInfo> = emptyList()

    var isOpen: Boolean = false
        private set

    init {
        visibility = View.GONE
        isClickable = true
        setBackgroundColor(Color.argb(228, 10, 12, 22))

        content.orientation = LinearLayout.VERTICAL
        addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val top = LinearLayout(context)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        input.hint = "Buscar"
        input.setHintTextColor(0x99FFFFFF.toInt())
        input.setTextColor(Color.WHITE)
        input.textSize = 17f
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.background = roundedBg(0x2EFFFFFF, context.dpf(12f))
        input.setPadding(context.dp(14), 0, context.dp(14), 0)
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                refresh(s?.toString().orEmpty())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        input.setOnEditorActionListener { _, _, _ ->
            val first = current.firstOrNull()
            val text = input.text.toString().trim()
            if (first != null) {
                pick(first, null)
            } else if (text.isNotEmpty()) {
                webSearch(text)
            }
            true
        }

        val cancel = TextView(context)
        cancel.text = "Cancelar"
        cancel.setTextColor(Color.WHITE)
        cancel.textSize = 16f
        cancel.gravity = Gravity.CENTER_VERTICAL
        cancel.setPadding(context.dp(14), 0, 0, 0)
        cancel.setOnClickListener { close() }

        top.addView(input, LinearLayout.LayoutParams(0, context.dp(44), 1f))
        top.addView(cancel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, context.dp(44)))
        content.addView(
            top,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        results.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(context)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(
            results,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        slp.topMargin = context.dp(12)
        content.addView(scroll, slp)
    }

    /** Respeta la barra de estado y el teclado. */
    fun setInsets(top: Int, bottom: Int) {
        content.setPadding(context.dp(16), top + context.dp(12), context.dp(16), bottom)
    }

    fun open() {
        isOpen = true
        animate().cancel()
        visibility = View.VISIBLE
        alpha = 0f
        animate().alpha(1f).setDuration(180).start()
        input.setText("")
        input.requestFocus()
        input.post {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    fun close() {
        if (!isOpen) return
        isOpen = false
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        animate().cancel()
        animate().alpha(0f).setDuration(120).withEndAction {
            if (!isOpen) visibility = View.GONE
        }.start()
    }

    private fun refresh(raw: String) {
        results.removeAllViews()
        val q = raw.trim()
        val query = q.lowercase()
        current = if (query.isEmpty()) {
            emptyList()
        } else {
            apps.filter { it.label.lowercase().contains(query) }
                .sortedBy { if (it.label.lowercase().startsWith(query)) 0 else 1 }
                .take(30)
        }
        for (app in current) results.addView(appRow(app))
        if (query.isNotEmpty()) results.addView(webRow(q))
    }

    private fun appRow(app: AppInfo): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, context.dp(8), 0, context.dp(8))

        val img = ImageView(context)
        img.setImageBitmap(app.icon)
        row.addView(img, LinearLayout.LayoutParams(context.dp(46), context.dp(46)))

        val tv = TextView(context)
        tv.text = app.label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 17f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = context.dp(14)
        row.addView(tv, lp)

        row.setOnClickListener { pick(app, img) }
        return row
    }

    private fun webRow(q: String): View {
        val tv = TextView(context)
        tv.text = "Buscar \u201C$q\u201D en la web"
        tv.setTextColor(Color.argb(220, 130, 190, 255))
        tv.textSize = 16f
        tv.setPadding(0, context.dp(16), 0, context.dp(16))
        tv.setOnClickListener { webSearch(q) }
        return tv
    }

    private fun pick(app: AppInfo, source: View?) {
        close()
        onLaunch(app, source)
    }

    private fun webSearch(q: String) {
        close()
        try {
            val url = "https://duckduckgo.com/?q=" + Uri.encode(q)
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // Sin navegador: no hacemos nada
        }
    }
}
