package com.ioc1.launcher

import android.content.Context

/** Guarda en el propio teléfono el orden de los iconos, el dock y el fondo. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("ioc1", Context.MODE_PRIVATE)

    /** Orden de las apps de la cuadrícula (claves de componente). */
    var order: List<String>
        get() = split(sp.getString("order", null))
        set(value) {
            sp.edit().putString("order", value.joinToString("\n")).apply()
        }

    /** Apps del dock; null si todavía no se ha guardado nada. */
    var dock: List<String>?
        get() = if (sp.contains("dock")) split(sp.getString("dock", null)) else null
        set(value) {
            val e = sp.edit()
            if (value == null) e.remove("dock") else e.putString("dock", value.joinToString("\n"))
            e.apply()
        }

    /** "preset:N" para un degradado o "photo" para una foto propia. */
    var wallpaper: String
        get() = sp.getString("wallpaper", "preset:0") ?: "preset:0"
        set(value) {
            sp.edit().putString("wallpaper", value).apply()
        }

    private fun split(s: String?): List<String> =
        if (s.isNullOrEmpty()) emptyList() else s.split("\n").filter { it.isNotBlank() }
}
