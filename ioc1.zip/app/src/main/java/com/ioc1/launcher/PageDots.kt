package com.ioc1.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Puntitos que indican en qué página estás. */
class PageDots(context: Context) : View(context) {

    var count: Int = 1
        set(value) {
            field = value
            invalidate()
        }

    var selected: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dim = 0x80FFFFFF.toInt()

    override fun onDraw(canvas: Canvas) {
        if (count <= 1) return
        val radius = context.dpf(3.5f)
        val gap = context.dpf(14f)
        var x = (width - (count - 1) * gap) / 2f
        val cy = height / 2f
        for (i in 0 until count) {
            paint.color = if (i == selected) Color.WHITE else dim
            canvas.drawCircle(x, cy, radius, paint)
            x += gap
        }
    }
}
