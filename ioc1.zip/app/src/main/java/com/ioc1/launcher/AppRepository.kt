package com.ioc1.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.provider.MediaStore

/** Lee las apps instaladas que se pueden abrir. */
object AppRepository {

    fun load(context: Context, iconSize: Int, cache: MutableMap<String, AppInfo>): List<AppInfo> {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val result = ArrayList<AppInfo>()

        for (ri in pm.queryIntentActivities(query, 0)) {
            val ai = ri.activityInfo ?: continue
            if (ai.packageName == context.packageName) continue
            val cn = ComponentName(ai.packageName, ai.name)
            val key = cn.flattenToString()
            val info = cache[key] ?: build(pm, ri, cn, key, iconSize) ?: continue
            cache[key] = info
            result.add(info)
        }

        // Olvida las apps que ya no están instaladas
        val present = result.map { it.key }.toSet()
        cache.keys.retainAll(present)

        result.sortBy { it.label.lowercase() }
        return result
    }

    private fun build(
        pm: PackageManager,
        ri: ResolveInfo,
        cn: ComponentName,
        key: String,
        iconSize: Int
    ): AppInfo? = try {
        AppInfo(key, cn, ri.loadLabel(pm).toString(), IconFactory.make(ri.loadIcon(pm), iconSize))
    } catch (e: Exception) {
        null
    }

    /** Teléfono, mensajes, navegador y cámara, si el sistema los tiene. */
    fun defaultDockKeys(context: Context, apps: List<AppInfo>): List<String> {
        val pm = context.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val keys = ArrayList<String>()
        for (intent in intents) {
            val pkg = try {
                pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            } catch (e: Exception) {
                null
            }
            if (pkg == null || pkg == "android") continue
            val app = apps.firstOrNull { it.component.packageName == pkg } ?: continue
            if (app.key !in keys) keys.add(app.key)
        }
        return keys
    }
}
