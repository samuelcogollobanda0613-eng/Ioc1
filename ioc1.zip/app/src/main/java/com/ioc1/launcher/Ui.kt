package com.ioc1.launcher

import android.content.Context
import android.graphics.drawable.GradientDrawable

/** Convierte dp a píxeles. */
fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

/** Convierte dp a píxeles (decimal). */
fun Context.dpf(value: Float): Float = value * resources.displayMetrics.density

/** Fondo rectangular redondeado de un solo color. */
fun roundedBg(color: Int, radiusPx: Float): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = radiusPx
    }
