package com.ioc1.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * IOC 1 — pantalla de inicio inspirada en el iPhone 13.
 *
 * Estructura de la pantalla (de arriba abajo):
 *   páginas de iconos  ->  puntos de página  ->  barra "Buscar"  ->  dock
 */
class MainActivity : Activity() {

    private companion object {
        const val COLS = 4
        const val DOCK_SIZE = 4
        const val REQ_PHOTO = 1001
    }

    private lateinit var prefs: Prefs
    private lateinit var wallpaperView: WallpaperView
    private lateinit var column: LinearLayout
    private lateinit var pager: SnapPager
    private lateinit var dots: PageDots
    private lateinit var dock: LinearLayout
    private lateinit var search: SearchOverlay

    private val cache = ConcurrentHashMap<String, AppInfo>()
    private var allApps: List<AppInfo> = emptyList()
    private val gridKeys = ArrayList<String>()
    private val dockKeys = ArrayList<String>()

    private var rows = 0
    private var rowHeight = 0
    private var iconPx = 0
    private var initialized = false

    @Volatile
    private var loading = false

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        iconPx = dp(60)
        setupWindow()
        buildUi()
        restoreWallpaper()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val i = intent ?: return
        if (i.action == Intent.ACTION_MAIN && i.hasCategory(Intent.CATEGORY_HOME)) {
            if (search.isOpen) search.close() else pager.goTo(0)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Un launcher nunca se cierra con "atrás": solo vuelve a la primera página.
        if (search.isOpen) {
            search.close()
        } else if (pager.currentPage != 0) {
            pager.goTo(0)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PHOTO && resultCode == RESULT_OK) {
            data?.data?.let { loadPhoto(it) }
        }
    }

    // ---------------------------------------------------------------- interfaz

    @Suppress("DEPRECATION")
    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }
    }

    @Suppress("DEPRECATION")
    private fun buildUi() {
        val root = FrameLayout(this)

        wallpaperView = WallpaperView(this)
        root.addView(wallpaperView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        root.addView(column, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // Páginas
        pager = SnapPager(this)
        pager.onPageChanged = { page -> dots.selected = page }
        pager.addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
            val h = bottom - top
            if (h > 0) pager.post { updateRows(h) }
        }
        column.addView(pager, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // Puntos
        dots = PageDots(this)
        column.addView(dots, LinearLayout.LayoutParams(MATCH_PARENT, dp(18)))

        // Barra de búsqueda
        val searchIcon = getDrawable(R.drawable.ic_search)
        val pill = TextView(this)
        pill.text = "Buscar"
        pill.setTextColor(Color.WHITE)
        pill.textSize = 15f
        pill.gravity = Gravity.CENTER
        pill.compoundDrawablePadding = dp(6)
        pill.setCompoundDrawablesWithIntrinsicBounds(searchIcon, null, null, null)
        pill.background = roundedBg(0x33FFFFFF, dpf(17f))
        pill.setPadding(dp(44), 0, dp(44), 0)
        pill.setOnClickListener { search.open() }
        val pillLp = LinearLayout.LayoutParams(WRAP_CONTENT, dp(34))
        pillLp.gravity = Gravity.CENTER_HORIZONTAL
        pillLp.topMargin = dp(2)
        pillLp.bottomMargin = dp(12)
        column.addView(pill, pillLp)

        // Dock
        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.background = roundedBg(0x40FFFFFF, dpf(34f))
        dock.setPadding(dp(8), dp(10), dp(8), dp(10))
        val dockLp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        dockLp.setMargins(dp(12), 0, dp(12), dp(10))
        column.addView(dock, dockLp)

        // Búsqueda
        search = SearchOverlay(this) { app, source -> launchApp(app, source) }
        root.addView(search, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        root.setOnApplyWindowInsetsListener { _, insets ->
            // "stable" ignora el teclado, así la pantalla de inicio no salta al escribir
            column.setPadding(0, insets.stableInsetTop, 0, insets.stableInsetBottom)
            search.setInsets(insets.systemWindowInsetTop, insets.systemWindowInsetBottom)
            insets
        }

        setContentView(root)
        root.requestApplyInsets()
    }

    /** Calcula cuántas filas caben y reconstruye las páginas si cambian. */
    private fun updateRows(pagerHeight: Int) {
        val usable = pagerHeight - dp(8)
        val newRows = (usable / dp(92)).coerceIn(3, 6)
        val newRowHeight = minOf(usable / newRows, dp(106))
        if (newRows != rows || newRowHeight != rowHeight) {
            rows = newRows
            rowHeight = newRowHeight
            render()
        }
    }

    private fun render(focusKey: String? = null) {
        if (rows == 0) return
        val byKey = allApps.associateBy { it.key }
        val perPage = COLS * rows
        val pageCount = maxOf(1, (gridKeys.size + perPage - 1) / perPage)

        val pages = ArrayList<View>()
        for (p in 0 until pageCount) pages.add(buildPage(p, perPage, byKey))
        pager.setPages(pages)
        dots.count = pageCount

        var target = minOf(pager.currentPage, pageCount - 1)
        if (focusKey != null) {
            val idx = gridKeys.indexOf(focusKey)
            if (idx >= 0) target = idx / perPage
        }
        pager.post { pager.goTo(target, false) }
        dots.selected = target

        renderDock(byKey)
    }

    private fun buildPage(page: Int, perPage: Int, byKey: Map<String, AppInfo>): View {
        val pageView = LinearLayout(this)
        pageView.orientation = LinearLayout.VERTICAL
        pageView.setPadding(dp(8), dp(8), dp(8), 0)
        pageView.setOnLongClickListener {
            showWallpaperMenu()
            true
        }

        val start = page * perPage
        for (r in 0 until rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until COLS) {
                val idx = start + r * COLS + c
                val app = gridKeys.getOrNull(idx)?.let { byKey[it] }
                val cellLp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
                if (app != null) {
                    row.addView(makeIcon(app, true, false), cellLp)
                } else {
                    row.addView(View(this), cellLp)
                }
            }
            pageView.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, rowHeight))
        }
        return pageView
    }

    private fun renderDock(byKey: Map<String, AppInfo>) {
        dock.removeAllViews()
        for (i in 0 until DOCK_SIZE) {
            val app = dockKeys.getOrNull(i)?.let { byKey[it] }
            if (app != null) {
                dock.addView(makeIcon(app, false, true), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            } else {
                dock.addView(View(this), LinearLayout.LayoutParams(0, iconPx, 1f))
            }
        }
    }

    private fun makeIcon(app: AppInfo, showLabel: Boolean, inDock: Boolean): AppIconView {
        val v = AppIconView(this, app, iconPx, showLabel)
        v.setOnClickListener { launchApp(app, v) }
        v.setOnLongClickListener {
            showAppMenu(app, inDock)
            true
        }
        return v
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        if (loading) return
        loading = true
        Thread {
            val list = try {
                AppRepository.load(this, iconPx, cache)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                loading = false
                if (list != null && !isDestroyed) applyApps(list)
            }
        }.start()
    }

    private fun applyApps(list: List<AppInfo>) {
        val same = initialized &&
            list.size == allApps.size &&
            list.indices.all { list[it].key == allApps[it].key }
        if (same) return
        allApps = list
        search.apps = list
        initialized = true
        normalizeLists()
        render()
    }

    /** Une lo guardado por el usuario con las apps que existen ahora mismo. */
    private fun normalizeLists() {
        if (allApps.isEmpty()) return
        val byKey = allApps.associateBy { it.key }

        val savedDock = prefs.dock
        val source = savedDock ?: AppRepository.defaultDockKeys(this, allApps)
        val d = ArrayList<String>()
        for (k in source) {
            if (byKey.containsKey(k) && k !in d && d.size < DOCK_SIZE) d.add(k)
        }
        if (savedDock == null) {
            for (a in allApps) {
                if (d.size >= DOCK_SIZE) break
                if (a.key !in d) d.add(a.key)
            }
        }
        dockKeys.clear()
        dockKeys.addAll(d)

        val g = ArrayList<String>()
        for (k in prefs.order) {
            if (byKey.containsKey(k) && k !in dockKeys && k !in g) g.add(k)
        }
        for (a in allApps) {
            if (a.key !in dockKeys && a.key !in g) g.add(a.key)
        }
        gridKeys.clear()
        gridKeys.addAll(g)
        persist()
    }

    private fun persist() {
        prefs.order = gridKeys.toList()
        prefs.dock = dockKeys.toList()
    }

    private fun launchApp(app: AppInfo, source: View?) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val options = if (source != null && source.width > 0) {
                ActivityOptions.makeScaleUpAnimation(source, 0, 0, source.width, source.height).toBundle()
            } else {
                null
            }
            startActivity(intent, options)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- menú de un icono

    private class MenuEntry(val label: String, val action: () -> Unit)

    private fun showAppMenu(app: AppInfo, inDock: Boolean) {
        val entries = ArrayList<MenuEntry>()
        if (inDock) {
            entries.add(MenuEntry("Quitar del dock") { removeFromDock(app.key) })
        } else {
            entries.add(MenuEntry("Mover a la izquierda") { moveInGrid(app.key, -1) })
            entries.add(MenuEntry("Mover a la derecha") { moveInGrid(app.key, 1) })
            entries.add(MenuEntry("Mover al principio") { moveToStart(app.key) })
            entries.add(MenuEntry("Poner en el dock") { addToDock(app.key) })
        }
        entries.add(MenuEntry("Información de la app") { openAppInfo(app) })

        val names = entries.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(names) { _, which -> entries[which].action() }
            .show()
    }

    private fun moveInGrid(key: String, delta: Int) {
        val i = gridKeys.indexOf(key)
        val j = i + delta
        if (i < 0 || j < 0 || j >= gridKeys.size) return
        Collections.swap(gridKeys, i, j)
        persist()
        render(key)
    }

    private fun moveToStart(key: String) {
        if (gridKeys.remove(key)) {
            gridKeys.add(0, key)
            persist()
            render(key)
        }
    }

    private fun addToDock(key: String) {
        if (dockKeys.size < DOCK_SIZE) {
            gridKeys.remove(key)
            dockKeys.add(key)
            persist()
            render()
            return
        }
        val byKey = allApps.associateBy { it.key }
        val names = dockKeys.map { "Reemplazar ${byKey[it]?.label ?: it}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("El dock está lleno")
            .setItems(names) { _, which ->
                val old = dockKeys[which]
                dockKeys[which] = key
                gridKeys.remove(key)
                gridKeys.add(0, old)
                persist()
                render(old)
            }
            .show()
    }

    private fun removeFromDock(key: String) {
        if (dockKeys.remove(key)) {
            gridKeys.add(0, key)
            persist()
            render(key)
        }
    }

    private fun openAppInfo(app: AppInfo) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.component.packageName}"))
            )
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir la información", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- fondo de pantalla

    private fun showWallpaperMenu() {
        val names = ArrayList<String>()
        for (p in WallpaperView.presets) names.add(p.name)
        names.add("Elegir una foto\u2026")
        names.add("Ordenar iconos de la A a la Z")

        AlertDialog.Builder(this)
            .setTitle("Personalizar IOC 1")
            .setItems(names.toTypedArray()) { _, which ->
                val presetCount = WallpaperView.presets.size
                when {
                    which < presetCount -> {
                        wallpaperView.setPreset(which)
                        prefs.wallpaper = "preset:$which"
                    }
                    which == presetCount -> pickPhoto()
                    else -> {
                        prefs.order = emptyList()
                        normalizeLists()
                        render()
                    }
                }
            }
            .show()
    }

    private fun restoreWallpaper() {
        val w = prefs.wallpaper
        if (w == "photo") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) {
                Thread {
                    val bmp = BitmapFactory.decodeFile(f.absolutePath)
                    if (bmp != null) runOnUiThread { wallpaperView.setPhoto(bmp) }
                }.start()
            }
        } else {
            wallpaperView.setPreset(w.removePrefix("preset:").toIntOrNull() ?: 0)
        }
    }

    private fun pickPhoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("image/*")
        try {
            startActivityForResult(intent, REQ_PHOTO)
        } catch (e: Exception) {
            Toast.makeText(this, "No hay ninguna app para elegir fotos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadPhoto(uri: Uri) {
        Thread {
            try {
                val dm = resources.displayMetrics

                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

                var sample = 1
                while (bounds.outWidth / (sample * 2) >= dm.widthPixels &&
                    bounds.outHeight / (sample * 2) >= dm.heightPixels
                ) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options()
                opts.inSampleSize = sample
                var bmp = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                }

                val rotation = try {
                    contentResolver.openInputStream(uri)?.use {
                        when (ExifInterface(it).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )) {
                            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                } catch (e: Exception) {
                    0f
                }

                if (bmp != null && rotation != 0f) {
                    val m = Matrix()
                    m.postRotate(rotation)
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }

                val finalBmp = bmp
                if (finalBmp == null) {
                    runOnUiThread {
                        Toast.makeText(this, "No se pudo leer la foto", Toast.LENGTH_SHORT).show()
                    }
                    return@Thread
                }

                File(filesDir, "wallpaper.jpg").outputStream().use {
                    finalBmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
                }
                runOnUiThread {
                    wallpaperView.setPhoto(finalBmp)
                    prefs.wallpaper = "photo"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "No se pudo usar esa foto", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
