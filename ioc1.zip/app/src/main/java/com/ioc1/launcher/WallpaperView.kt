package com.ioc1.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

/** Fondo de pantalla: degradados inspirados en el iPhone 13 o una foto elegida. */
class WallpaperView(context: Context) : View(context) {

    class Preset(val name: String, val top: Int, val bottom: Int, val blobs: IntArray)

    companion object {
        private fun c(hex: Long): Int = hex.toInt()

        val presets: List<Preset> = listOf(
            Preset(
                "Azul iPhone", c(0xFF0B1F7A), c(0xFF4B1E8C),
                intArrayOf(c(0xFF2F7BFF), c(0xFFB65CFF), c(0xFFFF6FA5))
            ),
            Preset(
                "Atardecer", c(0xFF3A1054), c(0xFFB5179E),
                intArrayOf(c(0xFFFF7A3D), c(0xFFFFC857), c(0xFFE63978))
            ),
            Preset(
                "Medianoche", c(0xFF050816), c(0xFF14213D),
                intArrayOf(c(0xFF1B3A8A), c(0xFF3D2C8D), c(0xFF0E6BA8))
            ),
            Preset(
                "Menta", c(0xFF053B3A), c(0xFF0B6E5C),
                intArrayOf(c(0xFF2EE6A8), c(0xFF3FA7FF), c(0xFFA8FF78))
            ),
            Preset(
                "Grafito", c(0xFF111111), c(0xFF2B2B2E),
                intArrayOf(c(0xFF555566), c(0xFF3A3A44), c(0xFF70707A))
            )
        )

        private val centers = arrayOf(
            floatArrayOf(0.15f, 0.20f),
            floatArrayOf(0.90f, 0.50f),
            floatArrayOf(0.30f, 0.95f)
        )
    }

    private var preset: Preset = presets[0]
    private var photo: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val scrim = Paint().apply { color = 0x2A000000 }
    private val drawMatrix = Matrix()

    fun setPreset(index: Int) {
        preset = presets.getOrElse(index) { presets[0] }
        photo = null
        invalidate()
    }

    fun setPhoto(bitmap: Bitmap) {
        photo = bitmap
        invalidate()
    }

    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val p = photo
        if (p != null) {
            val scale = maxOf(w / p.width, h / p.height)
            drawMatrix.setScale(scale, scale)
            drawMatrix.postTranslate((w - p.width * scale) / 2f, (h - p.height * scale) / 2f)
            paint.shader = null
            canvas.drawBitmap(p, drawMatrix, paint)
            canvas.drawRect(0f, 0f, w, h, scrim)
            return
        }

        paint.shader = LinearGradient(0f, 0f, w * 0.4f, h, preset.top, preset.bottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)

        val radius = maxOf(w, h) * 0.6f
        for (i in preset.blobs.indices) {
            val ctr = centers[i % centers.size]
            val color = preset.blobs[i]
            paint.shader = RadialGradient(
                ctr[0] * w, ctr[1] * h, radius,
                intArrayOf(withAlpha(color, 190), withAlpha(color, 0)),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, w, h, paint)
        }
        paint.shader = null
    }
}
