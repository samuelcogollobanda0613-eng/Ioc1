package com.ioc1.launcher

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Un icono con su nombre debajo (o sin nombre, en el dock). */
class AppIconView(
    context: Context,
    val app: AppInfo,
    iconSize: Int,
    showLabel: Boolean
) : LinearLayout(context) {

    init {
        orientation = LinearLayout.VERTICAL
        gravity = if (showLabel) {
            Gravity.CENTER_HORIZONTAL or Gravity.TOP
        } else {
            Gravity.CENTER
        }
        contentDescription = app.label

        val img = ImageView(context)
        img.setImageBitmap(app.icon)
        addView(img, LinearLayout.LayoutParams(iconSize, iconSize))

        if (showLabel) {
            val tv = TextView(context)
            tv.text = app.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            tv.setShadowLayer(context.dpf(2f), 0f, context.dpf(1f), 0x80000000.toInt())
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = context.dp(5)
            lp.leftMargin = context.dp(2)
            lp.rightMargin = context.dp(2)
            addView(tv, lp)
        }
    }

    /** Efecto de pulsación suave, como en iOS. */
    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        val s = if (pressed) 0.9f else 1f
        animate().scaleX(s).scaleY(s).setDuration(120).start()
    }
}
