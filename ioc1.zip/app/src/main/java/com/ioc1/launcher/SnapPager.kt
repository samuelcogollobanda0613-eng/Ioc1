package com.ioc1.launcher

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

/** Páginas deslizables que siempre se detienen justo en una página. */
class SnapPager(context: Context) : HorizontalScrollView(context) {

    private val container = LinearLayout(context)
    private var flung = false

    var currentPage = 0
        private set

    var onPageChanged: ((Int) -> Unit)? = null

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isFillViewport = true
        container.orientation = LinearLayout.HORIZONTAL
        addView(
            container,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }

    fun setPages(pages: List<View>) {
        container.removeAllViews()
        val pageWidth = if (width > 0) width else resources.displayMetrics.widthPixels
        for (page in pages) {
            container.addView(page, LinearLayout.LayoutParams(pageWidth, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        if (currentPage > pages.size - 1) currentPage = maxOf(0, pages.size - 1)
    }

    fun goTo(page: Int, animate: Boolean = true) {
        val last = maxOf(0, container.childCount - 1)
        val p = page.coerceIn(0, last)
        currentPage = p
        val x = p * width
        if (animate) smoothScrollTo(x, 0) else scrollTo(x, 0)
        onPageChanged?.invoke(p)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            val lp = child.layoutParams
            if (lp.width != w) {
                lp.width = w
                child.layoutParams = lp
            }
        }
        scrollTo(currentPage * w, 0)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
        val handled = super.onTouchEvent(ev)
        val action = ev.actionMasked
        if ((action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) && !flung) {
            snapToNearest()
        }
        return handled
    }

    override fun fling(velocityX: Int) {
        flung = true
        if (width == 0) return
        val target = when {
            velocityX > 500 -> currentPage + 1
            velocityX < -500 -> currentPage - 1
            else -> nearestPage()
        }
        goTo(target)
    }

    private fun nearestPage(): Int = ((scrollX + width / 2f) / width).toInt()

    private fun snapToNearest() {
        if (width == 0) return
        goTo(nearestPage())
    }
}
