package com.ioc1.launcher

import android.content.ComponentName
import android.graphics.Bitmap

/** Una app instalada, con su icono ya dibujado al estilo IOC. */
data class AppInfo(
    val key: String,
    val component: ComponentName,
    val label: String,
    val icon: Bitmap
)
