package com.ioc1.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/** Dibuja cualquier icono de Android dentro de un cuadrado redondeado, como en iOS. */
object IconFactory {

    fun make(drawable: Drawable, size: Int): Bitmap {
        // 1) Contenido cuadrado completo
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        c.drawColor(Color.rgb(242, 242, 247))

        if (drawable is AdaptiveIconDrawable) {
            // Las capas de un icono adaptable miden 108 dp y solo se ven 72 dp:
            // se amplían un 25 % por cada lado para llenar el cuadrado.
            val pad = (size * 0.25f).toInt()
            drawable.background?.let {
                it.setBounds(-pad, -pad, size + pad, size + pad)
                it.draw(c)
            }
            drawable.foreground?.let {
                it.setBounds(-pad, -pad, size + pad, size + pad)
                it.draw(c)
            }
        } else {
            val inset = (size * 0.14f).toInt()
            drawable.setBounds(inset, inset, size - inset, size - inset)
            drawable.draw(c)
        }

        // 2) Máscara con bordes suaves (esquinas tipo iOS)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val oc = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val radius = size * 0.2237f
        oc.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), radius, radius, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        oc.drawBitmap(content, 0f, 0f, paint)
        content.recycle()
        return out
    }
}
