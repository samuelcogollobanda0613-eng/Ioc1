# IOC 1 — versión 1.0 (Fase 1)

Launcher Android inspirado en el iPhone 13 (estilo iOS 16). Sin anuncios, sin permisos, sin dependencias externas.

- Iconos con esquinas tipo iOS, páginas deslizables y puntos de página
- Dock inferior de cuatro apps
- Barra "Buscar" para encontrar apps
- Fondos: 5 degradados o una foto propia
- Mantén pulsado un icono para moverlo, ponerlo en el dock o ver su información
- Mantén pulsado un espacio vacío para cambiar el fondo

Se compila en GitHub Actions (ver .github/workflows/build.yml).
